from __future__ import division, absolute_import
from __future__ import print_function, unicode_literals

import webbrowser
import random

from kivy.app import App
from kivy.clock import Clock
from kivy.uix.popup import Popup
from kivy.core.window import Window
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.screenmanager import Screen
from kivy.uix.gridlayout import GridLayout
from kivy.uix.button import Button
from kivy.properties import ObjectProperty
from kivy.utils import get_color_from_hex
from kivy.core.text import LabelBase

from inversee import Inversee,Difficile,seperate_string_number,Compte

# Couleur de fond
Window.clearcolor = get_color_from_hex("#AB1239")

# Police d'écriture
LabelBase.register(name="Roboto",fn_regular="./fonts/Roboto-Thin.ttf",fn_bold="./fonts/Roboto-Medium.ttf")
##################################################################


class RobotMathRoot(BoxLayout):
    facile_screen = ObjectProperty(None)
    difficile_screen = ObjectProperty(None)
    mult_screen = ObjectProperty(None)
    compte_screen = ObjectProperty()

    def __init__(self, **kwargs):
        super(RobotMathRoot, self).__init__(**kwargs)
        # Liste de tous les écrans précédents
        self.screen_list = []
        self.math_popup = MathPopup()

    def changeScreen(self, next_screen):
        question = None

        if self.ids.robot_screen_manager.current not in self.screen_list:
            self.screen_list.append(self.ids.robot_screen_manager.current)

        if next_screen == "a propos":
            self.ids.robot_screen_manager.current = "about_screen"

        else:
            if next_screen == "multiplication":
                self.ids.robot_screen_manager.current = "mult_screen"
            elif next_screen == "le compte est bon":
                question = self.compte_screen.get_liste()
                self.compte_screen.question_text.text = RobotMathRoot.prepQuestion(question)
                self.ids.robot_screen_manager.current = "compte_screen"

            elif next_screen == "facile":
                question = self.facile_screen.get_question()
                self.facile_screen.question_text.text = RobotMathRoot.prepQuestion(question)
                self.ids.robot_screen_manager.current = "facile_screen"

            elif next_screen == "difficile":
                question = self.difficile_screen.get_question()
                self.difficile_screen.question_text.text = RobotMathRoot.prepQuestion(question)
                self.ids.robot_screen_manager.current = "difficile_screen"

            else:
                self.facile_screen.question_text.text = next_screen
                self.ids.robot_screen_manager.current = "diff_screen"


    @staticmethod
    def prepQuestion(question):
        if isinstance(question,list):
            return "Trouvez le nombre "+str(question[1])+"\nen seulement "+str(question[0])+" opérations."
        if isinstance(question, tuple):
            return "Trouvez le nombre "+str(question[0])+"\navec seulement les nombres suivants:\n"+str(question[1])
        return "Trouvez le nombre "+str(question)

    def onBackBtn(self):
        # Vérifie s'il y a un écran vers lequel retourner
        if self.screen_list:  # le cas où il reste des écrans
            self.ids.robot_screen_manager.current = self.screen_list.pop()
            return True
        return False  # le cas où il n'en reste plus


##################################################################
class MultScreen(Screen):
    score = 0

    def __init__(self, **kwargs):
        super(MultScreen, self).__init__(**kwargs)
        self.randomValue = random.randint(0, 10)
        self.randomValue2 = random.randint(0, 10)
        self.resultat = self.randomValue * self.randomValue2
        # self.result_label.text = str(self.randomValue) + "*" + str(self.randomValue2) + "=?"
        # print(self.resultat)

    def check_number(self):
        # for i in range(3):

        if int(self.answer_input.text) == self.resultat:
            MultScreen.score += 1
            self.result_label.text = str(MultScreen.score)
            self.result_label.color = "#0065EF"
            self.randomValue = random.randint(0, 10)
            self.randomValue2 = random.randint(0, 10)
            self.resultat = self.randomValue * self.randomValue2
            self.result_label.text = str(self.randomValue) + "*" + str(self.randomValue2) + "=?"
            print("ok")


        elif int(self.answer_input.text) != self.resultat:
            MultScreen.score -= 1
            self.result_label.text = str(MultScreen.score)
            self.result_label.color = "#00EF0B"
            self.randomValue = random.randint(0, 10)
            self.randomValue2 = random.randint(0, 10)
            self.resultat = self.randomValue * self.randomValue2
            self.result_label.text = str(self.randomValue) + "*" + str(self.randomValue2) + "=?"

        if MultScreen.score == 5:
            self.result_label.text = "Bravo"
        print(self.resultat)
        print(MultScreen.score)
##################################################################


class MathPopup(Popup):
    GOOD = "{} :D"
    BAD = "{}. Le calcul n'est pas bon"
    GOOD_LIST = "Super! Formidable! Correct! Excellent!".split()
    BAD_LIST = ["Dommage!", "Presque!", "Pas loin!"]
    message = ObjectProperty()
    wrapped_button = ObjectProperty

    def __init__(self,*args,**kwargs):
        super(MathPopup, self).__init__(*args,**kwargs)

    def open(self,correct=True):
        # Si bonne réponse, enlever le button si il est visible
        if correct:
            if self.wrapped_button in self.content.children:
                self.content.remove_widget(self.wrapped_button)
        # Sinon, afficher le boutton s'il n'est pas visible
        else:
            if self.wrapped_button not in self.content.children:
                self.content.add_widget(self.wrapped_button)

        # Message à afficher
        self.message.text = self._prep_text(correct)

        # popup
        super(MathPopup,self).open()
        if correct:
            Clock.schedule_once(self.dismiss,1)

    def _prep_text(self,correct):
        if correct:
            index = random.randint(0,len(self.GOOD_LIST)-1)
            return self.GOOD.format(self.GOOD_LIST[index])
        else:
            index = random.randint(0, len(self.BAD_LIST) - 1)
            return self.BAD.format(self.BAD_LIST[index])

##################################################################


class KeyPad(GridLayout):

    def __init__(self, *args, **kwargs):
        super(KeyPad, self).__init__(*args, **kwargs)
        self.cols = 3
        self.spacing = 10
        self.createButtons()

    def createButtons(self):
        _list = [1, 2, 3, 4, 5, 6, 7, 8, 9, 0,"(",")", "+", "-", "*", "", "GO!"]
        for num in _list:
            self.add_widget(Button(text=str(num), on_release=self.onBtnPress))

    def onBtnPress(self, btn):
        math_screen = App.get_running_app().root.ids.facile_screen
        answer_text = math_screen.answer_text

        if btn.text != "GO!":
            answer_text.text += btn.text
        if btn.text == "GO!" and answer_text.text != "":
            rep = math_screen.get_rep(answer_text.text)
            answer = math_screen.get_answer()
            root = App.get_running_app().root
            if rep == answer:
                root.math_popup.open(True)
                print("Bien joué")
            else:
                root.math_popup.open(False)
                print("Mauvaise réponse")
            # Effacer le reste et afficher la question qui suit
            answer_text.text = ""
            # Preparer à avoir de nouvelles question :
            question = root.facile_screen.get_question()
            root.facile_screen.question_text.text = RobotMathRoot.prepQuestion(question)

##################################################################


class KeyPadDifficile(GridLayout):

    def __init__(self, *args, **kwargs):
        super(KeyPadDifficile, self).__init__(*args, **kwargs)
        self.cols = 3
        self.spacing = 10
        self.createButtons()

    def createButtons(self):
        _list = [1, 2, 3, 4, 5, 6, 7, 8, 9, 0,"(",")", "+", "-", "*", "", "GO!"]
        for num in _list:
            self.add_widget(Button(text=str(num), on_release=self.onBtnPress))

    def onBtnPress(self, btn):
        math_screen = App.get_running_app().root.ids.difficile_screen
        answer_text = math_screen.answer_text


        if btn.text != "GO!":
            answer_text.text += btn.text
        if btn.text == "GO!" and answer_text.text != "":
            a = seperate_string_number(answer_text.text)
            compteur = 0
            for i in a:
                try:
                    i = int(i)
                except Exception:
                    pass
                if isinstance(i, int):
                    compteur += 1

            rep = math_screen.get_rep(answer_text.text)
            answer = math_screen.get_answer()
            root = App.get_running_app().root
            if compteur != answer[0]:
                root.math_popup.open(False)
                print("Le nombre d'opérations n'est pas le bon")
            if rep == answer[1]:
                root.math_popup.open(True)
                print("Bien joué")
            else:
                root.math_popup.open(False)
                print("Mauvaise réponse")
            # Effacer le reste et afficher la question qui suit
            answer_text.text = ""
            # Preparer à avoir de nouvelles question :
            question = root.difficile_screen.get_question()
            root.difficile_screen.question_text.text = RobotMathRoot.prepQuestion(question)

##################################################################

class KeyPadCompte(GridLayout):


    def __init__(self, *args, **kwargs):
        super(KeyPadCompte, self).__init__(*args, **kwargs)
        self.cols = 3
        self.spacing = 10
        self.createButtons()





    def createButtons(self):
        """"
        if App.get_running_app().root:
            math_screen = App.get_running_app().root.ids.compte_screen
            _list = math_screen.get_liste()[1] + ["+", "-", "*", "", "GO!"]
            for num in self._list:
                self.add_widget(Button(text=str(num), on_release=self.onBtnPress))
        """
        _list = [1, 2, 3, 4, 5, 6, 7, 8, 9, 0,"(",")", "+", "-", "*", "", "GO!"]
        for num in _list:
            self.add_widget(Button(text=str(num), on_release=self.onBtnPress))

    def onBtnPress(self, btn):
        math_screen = App.get_running_app().root.ids.compte_screen
        answer_text = math_screen.answer_text

        if btn.text != "GO!":
            answer_text.text += btn.text
        if btn.text == "GO!" and answer_text.text != "":
            root = App.get_running_app().root
            a = seperate_string_number(answer_text.text)
            compteur = 0
            for i in a:
                try:
                    i = int(i)
                except Exception:
                    pass
                if isinstance(i, int):
                    l = math_screen.get_l()
                    if int(i) not in l:
                        print("Vous ne devez utiliser que des valeurs présentes dans la liste suivante :")
                        root.math_popup.open(False)
                    compteur += 1
            if compteur != 4:
                print("Vous n'avez pas utiliser la bonne quantité de nombres ! Vous perdez une vie. Il ne vous en "
                      "reste que", )
                root.math_popup.open(False)
            rep = math_screen.get_rep(answer_text.text)
            answer = math_screen.get_answer()
            root = App.get_running_app().root
            if rep == answer:
                root.math_popup.open(True)
                print("Bien joué")
            else:
                root.math_popup.open(False)
                print("Mauvaise réponse")
            # Effacer le reste et afficher la question qui suit
            answer_text.text = ""
            # Preparer à avoir de nouvelles question :
            question = root.compte_screen.get_liste()
            root.compte_screen.question_text.text = RobotMathRoot.prepQuestion(question)

##################################################################


class FacileScreen(Screen, Inversee):
    def __init__(self, *args, **kwargs):
        super(FacileScreen, self).__init__(*args, **kwargs)


class DifficileScreen(Screen, Difficile):
    def __init__(self, *args, **kwargs):
        super(DifficileScreen, self).__init__(*args, **kwargs)


class CompteScreen(Screen, Compte):
    def __init__(self, *args, **kwargs):
        super(CompteScreen, self).__init__(*args, **kwargs)

##################################################################


class RobotMathApp(App):
    def __init__(self, **kwargs):
        super(RobotMathApp, self).__init__(**kwargs)
        Window.bind(on_keyboard=self.onBackBtn)

    def onBackBtn(self, window, key, *args):
        # lorsque l'utilisateur appuies sur ECHAP
        if key == 27:
            return self.root.onBackBtn()

    def build(self):
        return RobotMathRoot()

    def getText(self):
        return ("Bienvenue dans l'app Robot Pédagogique !\n"
                "Cette app a été créée à l'aide du youtubeur [b][ref=yt]Daniel Gopar[/ref][/b]\n"
                "ainsi qu'à l'aide de [b][ref=kivy]kivy[/ref][/b]\n"
                "Un grand merci à Daniel Gopar et à sa suite de [b][ref=video]vidéos[/ref][/b] sur Math Tutor")

    def on_ref_press(self, instance, ref):
        _dict = {
            "kivy": "https://kivy.org/#home",
            "yt": "https://www.youtube.com/channel/UCCRdRbI93UGW0AZttVH3SbA",
            "video": "https://www.youtube.com/watch?v=qVL05_-Bmok&list=PL3kg5TcOuFlqHsEtDKneH56oHypWdHXwj"
        }

        webbrowser.open(_dict[ref])


if __name__ == '__main__':
    RobotMathApp().run()
